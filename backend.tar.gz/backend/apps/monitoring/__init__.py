default_app_config = 'apps.monitoring.apps.MonitoringConfig'
